import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import ProtectedRoute from './pages/ProtectedRoute';
import Dashboard from './pages/Dashboard';
import Report from './pages/Report';
import UserManagement from './pages/UserManagement';
function App() {
  return (
<>
<Router >


            <Routes>
                    <Route element={<ProtectedRoute/>}>
                        <Route exact path='/' element={< Dashboard />}></Route>
                        <Route exact path='/report' element={< Report />}></Route>
                        <Route exact path='/user-management' element={< UserManagement />}></Route>
                    </Route>
                    
                 <Route exact path='/login' element={< Login />}></Route>


   
          </Routes>



       </Router>

</>
  );
}

export default App;
