// import * as echarts from 'echarts';



import React, { PureComponent } from "react";
import ReactEcharts from "echarts-for-react";

class LineChart2 extends PureComponent {
  getOption = () => (
     {
      xAxis: {
        type: 'category',
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          data: [120, 200, 150, 80, 70, 110, 130],
          type: 'bar'
        }
      ]
    });

  render() {
    return (
      <ReactEcharts
        option={this.getOption()}
        style={{ height: "50%", width: "100%" }}
      />
    );
  }
}

export default LineChart2