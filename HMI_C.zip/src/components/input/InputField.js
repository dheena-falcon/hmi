import React from 'react'
import './inputField.css'
// import { AiFillAlert} from 'react-icons/ai'

function InputField({placeholder,type,callback,value,lable,icon}) {
  // console.log(icon);
  return (
    <>
    <div className='input-container'>
    <span className='lable'>{lable}</span>
    <span className='icon'>{icon}</span>
    <input className='input-field'   autoComplete='new-password' type={type} placeholder={placeholder} name="usrnm" onChange={(e)=>callback(e)} value={value}/>
  </div>
    </>

   
  )
}

export default InputField