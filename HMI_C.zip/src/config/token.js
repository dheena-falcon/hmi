var token =localStorage.getItem('accessToken')
  var config = {
    headers:  {
      "Authorization":'Bearer '  + token,
    }
  }

  export default config