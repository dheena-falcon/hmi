// import { format } from 'date-fns'

export const COLUMNS = [
  {
    Header: 'S.No',
    accessor: '_id',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },
  {
    Header: 'Room Name',
    accessor: 'room_name',
    sticky: 'left'
  },
  {
    Header: 'No Pax',
    accessor: 'no_of_pax',

  },
  {
    Header: 'List Pax',
    accessor: 'list_of_pax',

  },
  {
    Header: 'Organizer',
    accessor: 'organizer_email',
    sticky: 'left'
  },
  {
    Header: 'Booked Date',
    accessor: 'booking_date',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'Reserved Date',
    accessor: 'reserved_date',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'Start Time',
    accessor: 'start_time'
  },
  {
    Header: 'End Time',
    accessor: 'end_time'
  },

  {
    Header: 'Status',
    accessor: 'current_status',
    Cell: s => {
     return<>
           <span className={
      s.value === 'Completed'?'greencolor'
      :s.value === 'Reserved'?'orangecolor':
       s.value === 'Occupied'?'redcolor':null}>
        
      </span>
      {s.value}
     </>

  }
  },
]

export const Desk = [
  {
    Header: 'S.No',
    accessor: '_id',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },
  {
    Header: 'Floor Name',
    accessor: 'floor_name',
    sticky: 'left'
  },
  {
    Header: 'Zone Name',
    accessor: 'zone_name',

  },
  {
    Header: 'Table Name',
    accessor: 'table_name',

  },
  {
    Header: 'Seat Name',
    accessor: 'seat_name',
    sticky: 'left'
  },
  {
    Header: 'Booked Date',
    accessor: 'booking_date',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'Reserved Date',
    accessor: 'reserved_date',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'Start Time',
    accessor: 'start_time'
  },
  {
    Header: 'End Time',
    accessor: 'end_time'
  },

  {
    Header: 'Status',
    accessor: 'current_status',
    Cell: s => {
     return<>
           <span className={
      s.value === 'Completed'?'greencolor'
      :s.value === 'Reserved'?'orangecolor':
       s.value === 'Occupied'?'redcolor':null}>
        
      </span>
      {s.value}
     </>

  }
  },
]


// export const GROUPED_COLUMNS = [
//   {
//     Header: 'Id',
//     Footer: 'Id',
//     accessor: 'id'
//   },
//   {
//     Header: 'Name',
//     Footer: 'Name',
//     columns: [
//       {
//         Header: 'First Name',
//         Footer: 'First Name',
//         accessor: 'first_name'
//       },
//       {
//         Header: 'Last Name',
//         Footer: 'Last Name',
//         accessor: 'last_name'
//       }
//     ]
//   },
//   {
//     Header: 'Info',
//     Footer: 'Info',
//     columns: [
//       {
//         Header: 'Date of Birth',
//         Footer: 'Date of Birth',
//         accessor: 'date_of_birth'
//       },
//       {
//         Header: 'Country',
//         Footer: 'Country',
//         accessor: 'country'
//       },
//       {
//         Header: 'Phone',
//         Footer: 'Phone',
//         accessor: 'phone'
//       }
//     ]
//   }
// ]



// export const UserMan = [
//   {
//     Header: 'S.No',
//     accessor: '_id',
//     Cell: (row) => {
//       return <div>{row.row.id*1+1}</div>;
//   },
//   // disableSortBy: true,
//   // disableFilters: true,
//   },

//   {
//     Header: 'Name',
//     accessor: 'name',
//     sticky: 'left'
//   },
//   {
//     Header: 'Email',
//     accessor: 'email',
//     sticky: 'left'
//   },
//   {
//     Header: 'Designation',
//     accessor: 'designation',
//     sticky: 'left'
//   },
//   {
//     Header: 'Department',
//     accessor: 'department',
//     sticky: 'left'
//   },
//   {
//     Header: 'Phone_no',
//     accessor: 'phoneno',
//     sticky: 'left'
//   },
// ]


// export const MasterOcu = [
//   {
//     Header: 'S.No',
//     accessor: '_id',
//     Cell: (row) => {
//       return <div>{row.row.id*1+1}</div>;
//   },
//   // disableSortBy: true,
//   // disableFilters: true,
//   },

//   {
//     Header: 'Room Name',
//     accessor: 'room_name',

//   },
//   {
//     Header: 'Room Id',
//     accessor: 'device_id',
//     width:100
//   },
//   {
//     Header: 'No-Pack',
//     accessor: 'no_of_pax',
//   },

//   {
//     Header: 'Status',
//     accessor: 'status',

//   },

// ]


export const Reports = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Employee Name',
    accessor: 'employee_name',
    sticky: 'left'
  },
  {
    Header: 'Date',
    accessor: 'date',
    sticky: 'left'
  },
  {
    Header: 'Department',
    accessor: 'department',
  },
  {
    Header: 'Expirey Time',
    accessor: 'expirey_time',
    sticky: 'left'
  },
  {
    Header: 'In Time',
    accessor: 'in_time',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'Out Time',
    accessor: 'out_time',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  // {
  //   Header: 'Start Time',
  //   accessor: 'start_time',
  //   sticky: 'left'
  // },
  // {
  //   Header: 'End Time',
  //   accessor: 'end_time',
  //   sticky: 'left'
  // },
  // {
  //   Header: 'Current Status',
  //   accessor: 'status',
  //   sticky: 'left'
  // },

]

export const User = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Employee Name',
    accessor: 'employee_name',
    sticky: 'left'
  },
  {
    Header: 'Date',
    accessor: 'date',
    sticky: 'left'
  },
  {
    Header: 'emp_id',
    accessor: 'emp_id',
  },
  {
    Header: 'start_time',
    accessor: 'start_time',
    sticky: 'left'
  },
  {
    Header: 'end_time',
    accessor: 'end_time',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'address',
    accessor: 'address',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  },
  {
    Header: 'attandance',
    accessor: 'attandance',
    sticky: 'left'
  },
  // {
  //   Header: 'End Time',
  //   accessor: 'end_time',
  //   sticky: 'left'
  // },
  // {
  //   Header: 'Current Status',
  //   accessor: 'status',
  //   sticky: 'left'
  // },

]


export const invoice = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Room Name',
    accessor: 'room_name',
    sticky: 'left'
  },
  {
    Header: 'Floor No',
    accessor: 'floor_name',
    sticky: 'left'
  },
  
  {
    Header: 'Status',
    accessor: 'status',
    sticky: 'left'
  },
  

]


export const Companies_data = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Companies ',
    accessor: 'name',
  },
  {
    Header: 'Logins',
    accessor: 'logins',
  },
  {
    Header: 'Subcripction Plan',
    accessor: 'subscription_plan',
  },
  {
    Header: 'Purchased On ',
    accessor: 'purchased_on',
  },
  {
    Header: 'Status',
    accessor: 'status',
  },
  {
    Header: 'Renewal On',
    accessor: 'renewal_on',
  },

]

// export const EmailLogs = [
//   {
//     Header: 'S.No',
//     accessor: 'id',
//     width: 10,
//   },

//   {
//     Header: 'Email',
//     accessor: 'email',
//     width: 80,
//   },
//   {
//     Header: 'Subject',
//     accessor: 'subject',
//   },
//   {
//     Header: 'Date',
//     accessor: 'date',
//     // Cell: ({ value }) => {
//     //   return format(new Date(value), 'dd/MM/yyyy')
//     // }
//   },

// ]



export const SuperAdmin = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Name',
    accessor: 'name',
    sticky: 'left'
  },
  {
    Header: 'Email id',
    accessor: 'email',
    sticky: 'left'
  },
  {
    Header: 'Purchased On',
    accessor: 'createdAt',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  }
]


export const Plans = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Plan Name',
    accessor: 'name',
    sticky: 'left'
  },
  {
    Header: 'Strip ID',
    accessor: 'strip_id',
    sticky: 'left'
  },
  {
    Header: 'User count',
    accessor: 'user_count',
    sticky: 'left'
  },
  {
    Header: 'Price',
    accessor: 'price',
    sticky: 'left'
  },
  {
    Header: 'Status',
    accessor: 'status',
    // Cell: ({ value }) => {
    //   return format(new Date(value), 'dd/MM/yyyy')
    // }
  }
]



export const facilitylist = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Facility',
    accessor: 'facility',
    sticky: 'left'
  },
  {
    Header: 'Authentication ',
    accessor: 'Authentication ',
    sticky: 'left'
  },

]

export const authList = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'Authentication ',
    accessor: 'name',
    sticky: 'left'
  },

]


export const UserList = [
  {
    Header: 'S.No',
    accessor: '',
    Cell: (row) => {
      return <div>{row.row.id*1+1}</div>;
  },
  },

  {
    Header: 'name ',
    accessor: 'name',
    sticky: 'left'
  },
  {
    Header: 'designation ',
    accessor: 'designation',
    sticky: 'left'
  },
  {
    Header: 'department ',
    accessor: 'department',
    sticky: 'left'
  },
  {
    Header: 'phone_no ',
    accessor: 'phone_no',
    sticky: 'left'
  },
  {
    Header: 'role ',
    accessor: 'role',
    sticky: 'left'
  },
  {
    Header: 'gender',
    accessor: 'gender',
    sticky: 'left'
  },

]