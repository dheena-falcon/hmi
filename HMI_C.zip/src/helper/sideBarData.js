
import { IoGridOutline } from 'react-icons/io5';
import { BsBarChart } from 'react-icons/bs';
import { MdOutlineMail } from 'react-icons/md';
import { MdSettingsSuggest } from 'react-icons/md';
import { BiUserVoice } from 'react-icons/bi';
import { SiAuthy } from 'react-icons/si';

export const obj = [
    {  
    "id":1,
    "icon":<IoGridOutline/>,
    "menu_name":"Dashboard",
    "route":"/"
    },
    {  
        "id":2,
        "icon":<MdSettingsSuggest/>,
        "menu_name":"Report",
        "route":"report"
        },
        {  
        "id":3,
        "icon":<BiUserVoice/>,
        "menu_name":"User Management",
        "route":"user-management"
        },


]
