



import '../Styles/global.css'
import '../Styles/Dashboard.css'
import React, { useMemo,useState,useEffect } from "react";
import "react-calendar/dist/Calendar.css";
import { GiMedicinePills} from 'react-icons/gi';
import { useTable,usePagination,useFilters, useGlobalFilter ,useSortBy } from 'react-table'
import MOCK_DATA from '../helper/Report.json'
import { Reports } from '../helper/columns'
import { AiOutlineCalendar } from 'react-icons/ai';
import { BsEye } from 'react-icons/bs';
// import { GlobalFilter } from "../components/table_filter/GlobalFilter";
import { ColumnFilter } from '../components/table_filter/ColumnFilter'
import axios from "axios";
import { useNavigate } from "react-router-dom";
import LineChart2 from '../components/chart/LineChart';
import img1 from '../assests/paste.svg'
function Dashboard() {
  const [roomTableData ,setRoomTableData] = useState([])
  const [departmentData ,setdepartmentData] = useState([])
  const [showRoom, setshowRoom] = useState(false)
  const [roomName, setroomName] = useState(null)
  const [noPax, setnoPax] = useState(null)
  const [orgName, setorgName] = useState(null)
  const [bdate, setbdate] = useState(null)
  const [rdate, setrdate] = useState(null)
  const [startTime, setstartTime] = useState(null)
  const [endTime, setendTime] = useState(null)
  const [coMember, setcoMember] = useState(null)
  const [status, setstatus] = useState(null)
  const columns = useMemo(() => Reports, [])
  const data = useMemo(() =>MOCK_DATA , [])
  const history = useNavigate()
  const defaultColumn = React.useMemo(
    () => ({
      Filter: ColumnFilter
    }),
    []
  )

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    gotoPage,
    pageCount,
    setPageSize,
    prepareRow,
    // setGlobalFilter
  } = useTable(
    {
      columns,
      data,
      defaultColumn,
      initialState: { pageIndex: 0 }
    },
    useFilters,
    useGlobalFilter,
    useSortBy,
    usePagination,
  )
  const { pageIndex, pageSize } = state

  





  const EditRoom = (d)=>{
    console.log(d);
  setroomName(d.room_name)
  setnoPax(d.no_of_pax)
  setorgName(d.organiser_name)
  setbdate(d.booking_date)
  setrdate(d.reserved_date)
  setstartTime(d.start_time)
  setendTime(d.end_time)
  setstatus(d.current_status)
  setcoMember(d.co_member)
  console.log(coMember);
  setshowRoom(true)
  }
  
  const cancel = ()=>{
    setshowRoom(false)
  }
  // 

function exportPDF(id) {
window.print()
}


const reload = ()=>{
  history(0)
}
const reset = ()=>{
  reload()
}
  // 
  return (
    <>
        <div className='app-header'> 
          <h1>Dashboard</h1>
        </div>
        <div className='dashboard-chart'>
          <div className='dashboard-chart-item'>
            <div className='chart-heading'>
              <GiMedicinePills/>
              <div>
                <h3>Benadryl</h3>
                <h4>8 hours</h4>
              </div>
            </div>
            <div className='dashboard-chart-list'>
              <div className='dashboard-chart-list-item'>
                    <span>150</span>
                    {[...new Array(10)].map((d,i)=>{
                    return <>
                    <span className='list-item-bar'></span>
                    
                    </> 
                  })
                  }
                  <span>In</span>
              </div>
              <div className='dashboard-chart-list-item'>
              <span>100</span>
                    {[...new Array(6)].map((d,i)=>{
                    return <span className='list-item-bar'></span>
                  })
                  
                  }
                  <span>Out</span>
              </div>
              <div className='dashboard-chart-list-item'>
              <span>50</span>
                    {[...new Array(2)].map((d,i)=>{
                    return <span className='list-item-bar'></span>
                  })
                  
                  }
                  <span>Waste</span>
              </div>


          </div>
          </div>
          <div className='dashboard-chart-item'>
            <div className='chart-heading'>
              <GiMedicinePills/>
              <div>
                <h3>Benadryl</h3>
                <h4>8 hours</h4>
              </div>
            </div>
            <div className='dashboard-chart-list'>
              <div className='dashboard-chart-list-item'>
                    <span>150</span>
                    {[...new Array(10)].map((d,i)=>{
                    return <>
                    <span className='list-item-bar'></span>
                    
                    </> 
                  })
                  }
                  <span>In</span>
              </div>
              <div className='dashboard-chart-list-item'>
              <span>100</span>
                    {[...new Array(6)].map((d,i)=>{
                    return <span className='list-item-bar'></span>
                  })
                  
                  }
                  <span>Out</span>
              </div>
              <div className='dashboard-chart-list-item'>
              <span>50</span>
                    {[...new Array(2)].map((d,i)=>{
                    return <span className='list-item-bar'></span>
                  })
                  
                  }
                  <span>Waste</span>
              </div>


          </div>
          </div>
          <div className='dashboard-chart-item'>
            <div className='chart-heading'>
              <GiMedicinePills/>
              <div>
                <h3>Benadryl</h3>
                <h4>8 hours</h4>
              </div>
            </div>
            <div className='dashboard-chart-list'>
              <div className='dashboard-chart-list-item'>
                    <span>150</span>
                    {[...new Array(10)].map((d,i)=>{
                    return <>
                    <span className='list-item-bar'></span>
                    
                    </> 
                  })
                  }
                  <span>In</span>
              </div>
              <div className='dashboard-chart-list-item'>
              <span>100</span>
                    {[...new Array(6)].map((d,i)=>{
                    return <span className='list-item-bar'></span>
                  })
                  
                  }
                  <span>Out</span>
              </div>
              <div className='dashboard-chart-list-item'>
              <span>50</span>
                    {[...new Array(2)].map((d,i)=>{
                    return <span className='list-item-bar'></span>
                  })
                  
                  }
                  <span>Waste</span>
              </div>


          </div>
          </div>



        </div>
        <div className='lineChart'>
        <LineChart2></LineChart2>
        </div>
    </>

  )
}

export default Dashboard


