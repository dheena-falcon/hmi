import React, {  useState } from "react";
import '../Styles/Login.css'
import logo from '../assests/logoN.svg'
import InputField from '../components/input/InputField'
import { VscLock} from 'react-icons/vsc'
import { BiUser} from 'react-icons/bi'
import { Link } from "react-router-dom";
import axios from "axios";
import {Navigate } from "react-router-dom";
function Login() {
  const [name, setName] = useState('');
  const [password, setpassword] = useState('');
  const [login, setlogin] = useState('');

const handleLogin = async()=>{
// if(!name){
//   alert('Please Enter Name')
// }else if(!password){
//   alert('Please Enter Password')
// }
// else{

// }
localStorage.setItem('user','trtrtrtrt')

window.location.replace('/')

}
  return (
    <div className='login-wrapper'>
    <div className='login-container border-blue'>
      <div className='loin-logo'>
        <img src={logo} alt='logo'/>
      </div>

      <h1 className="AllertaFont">Login</h1>
      {login && login}
      <InputField icon={<BiUser/>} placeholder='Type Your Username' lable='Username' type='text' callback={(event)=>setName(event.target.value)} value={name}/>
      <InputField icon={<VscLock/>} placeholder='Type Your Password' lable='Password' type='password' callback={(event)=>setpassword(event.target.value)} value={password}/>
      <h6> <Link to='/forget-password'>Forget Password?</Link></h6>

      <button className='login-btn' onClick={handleLogin}>Login</button>
      {/* <h2><span>OR</span></h2> */}
    </div>
    </div>

  )
}

export default Login