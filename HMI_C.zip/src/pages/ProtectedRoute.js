import React from "react";
import {Outlet,Navigate } from "react-router-dom";
import SideBar from '../components/sideBar/SideBar';
import axios from "axios";
function ProtectedRoute({ component: Component, ...restOfProps }) {
  // let auth = localStorage.getItem('user')



 
    return (
      true?
      <>  <div style={{display:'flex'}}>
          <SideBar/>
          <div style={{flexGrow:1,minHeight:'100vh'}} className='content-container'>
          <Outlet/>
          </div>
          </div>
      </> : <Navigate to='/login'/>
    )
}

export default ProtectedRoute;