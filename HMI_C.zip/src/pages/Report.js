


import '../Styles/global.css'
import React, { useMemo,useState,useEffect } from "react";
import "react-calendar/dist/Calendar.css";
import { FiChevronLeft,FiChevronRight,FiChevronsLeft,FiChevronsRight} from 'react-icons/fi';
import { useTable,usePagination,useFilters, useGlobalFilter ,useSortBy } from 'react-table'
import MOCK_DATA from '../helper/Report.json'
import { Reports } from '../helper/columns'
import { AiOutlineCalendar } from 'react-icons/ai';
import { BsEye } from 'react-icons/bs';
import {BiEdit} from 'react-icons/bi'
import { GlobalFilter } from "../components/table_filter/GlobalFilter";
import { ColumnFilter } from '../components/table_filter/ColumnFilter'
import axios from "axios";
import { useNavigate } from "react-router-dom";
function Report() {
  const [roomTableData ,setRoomTableData] = useState([])
  const [departmentData ,setdepartmentData] = useState([])
  const [showRoom, setshowRoom] = useState(false)
  const [roomName, setroomName] = useState(null)
  const [noPax, setnoPax] = useState(null)
  const [orgName, setorgName] = useState(null)
  const [bdate, setbdate] = useState(null)
  const [rdate, setrdate] = useState(null)
  const [startTime, setstartTime] = useState(null)
  const [endTime, setendTime] = useState(null)
  const [coMember, setcoMember] = useState(null)
  const [status, setstatus] = useState(null)
  const columns = useMemo(() => Reports, [])
  const data = useMemo(() =>MOCK_DATA , [])
  const history = useNavigate()
  const defaultColumn = React.useMemo(
    () => ({
      Filter: ColumnFilter
    }),
    []
  )

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    gotoPage,
    pageCount,
    setPageSize,
    prepareRow,
    setGlobalFilter
  } = useTable(
    {
      columns,
      data,
      defaultColumn,
      initialState: { pageIndex: 0 }
    },
    useFilters,
    useGlobalFilter,
    useSortBy,
    usePagination,
  )
  const { pageIndex, pageSize } = state

  





  const EditRoom = (d)=>{
    console.log(d);
  setroomName(d.room_name)
  setnoPax(d.no_of_pax)
  setorgName(d.organiser_name)
  setbdate(d.booking_date)
  setrdate(d.reserved_date)
  setstartTime(d.start_time)
  setendTime(d.end_time)
  setstatus(d.current_status)
  setcoMember(d.co_member)
  console.log(coMember);
  setshowRoom(true)
  }
  
  const cancel = ()=>{
    setshowRoom(false)
  }
  // 

function exportPDF(id) {
window.print()
}


const reload = ()=>{
  history(0)
}
const reset = ()=>{
  reload()
}
  // 
  return (
    <>
        <div className='app-header'> 
          <h1>Report</h1>
          {/* <InputField icon={<BiSearchAlt2/>} placeholder='Search' type='text'/>   */}

        </div>
        <div className='report-btn'>
              {/* <button id='HotDesking' className='report-btn-item   active' onClick={MeetingRoom}>Meeting Room</button> */}
              {/* <button id='Room' className='report-btn-item  ' onClick={Room}>Meeting Room</button>
              <button id='Locker' className='report-btn-item  ' onClick={Locker}>Locker</button> */}
          </div>
        <div className='  border-radius5px management-wrapper box-shadow'>
          <div className='manament-table-header'>
            <span className='AllertaFont'>REPORT</span>
            <div className='btn-divder'>

                    {/* <Multiselect
                    className='blue-btn-box usermangement-room-book-btn'
                      displayValue="departmentName"
                      onKeyPressFn={function noRefCheck(){}}
                      onRemove={function noRefCheck(){}}
                      onSearch={function noRefCheck(){}}
                      onSelect={function noRefCheck(){}}
                      options={departmentData}
                      singleSelect
                    /> */}
            <button className='blue-btn-box usermangement-room-book-btn' onClick={()=>exportPDF('test')}>Export <AiOutlineCalendar/></button>

                <select name="cars" id="status" className='blue-btn-box usermangement-room-book-btn report-department-select'  >
                  <option value="" disabled selected>Benadryl</option>
                  <option value="Completed">Benadryl 1</option>
                  <option value="Reserved">Benadryl 2</option>
                  <option value="Occupied">Benadryl 3</option>
                  {/* {departmentData.map((d,i)=>{
                    return <option key={i} value={d.departmentName}>{d.departmentName}</option>
                  })} */}
                </select>
                <select style={{minWidth:'200px'}} name="cars" id="status" className='blue-btn-box usermangement-room-book-btn report-department-select'  >
                  <option value="" disabled selected>Select Department</option>
                  <option value="Completed">Department 1</option>
                  <option value="Reserved">Department 2</option>
                  <option value="Occupied">Department 3</option>
                  {/* {departmentData.map((d,i)=>{
                    return <option key={i} value={d.departmentName}>{d.departmentName}</option>
                  })} */}
                </select>
{/* <GlobalFilter/> */}
            {/* <button className='blue-btn-box usermangement-room-book-btn'>Department <AiOutlineCalendar/></button> */}
            {/* <SimpleDropDown/> */}
            <button className='usermangement-reset-btn' onClick={reset}>Reset</button>
            </div>

          </div>
          {/* divder */}
          <div className='justify-center'>
          <span className='divder'></span>
          </div>

          <div className='table-container'>
          <>
      <table {...getTableProps()} id='test'>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}
               
                >
                 <div>{column.canFilter ? column.render('Filter') : null}</div>
                                 <span className="table-asc-dec"  onClick={() => column.toggleSortBy()}>
                <span>{column.render('Header')}</span> 
                <span>  {column.isSorted
                      ? column.isSortedDesc
                        ? ' 🔽'
                        : ' 🔼'
                      : ''}</span> 

                  </span>
                </th>
              ))}
              <th><div className="margintop2rem">Action</div></th>
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {page.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => {
                  return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                })}
                <td ><BiEdit {...row.getRowProps()} onClick={()=>EditRoom(row.original)} className='cursor-pointer' /></td>
              </tr>
            )
          })}
        </tbody>
      </table>
      <div className="pagination-section">


            <div className="pagination-page-section">
            <div>
              <span>
              Page
              <strong>
                {pageIndex + 1} of {pageOptions.length}
              </strong>
            </span>
          </div>
                <span>
              | Go to page:{' '}
              <input
                type='number'
                defaultValue={pageIndex + 1}
                onChange={e => {
                  const pageNumber = e.target.value ? Number(e.target.value) - 1 : 0
                  gotoPage(pageNumber)
                }}
                style={{ width: '50px' }}
              />
            </span>{' '}
            </div>
                

        <div className="pagination-btn-section">
        <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
         <FiChevronsLeft/>
        </button>
        <button onClick={() => previousPage()} disabled={!canPreviousPage}>
        <FiChevronLeft/> <span>Previous</span>
        </button>
        <button onClick={() => nextPage()} disabled={!canNextPage}>
        <span>Next</span>   <FiChevronRight/>
        </button>
        <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
        <FiChevronsRight/> 
        </button>
        </div>

                <div className="pagination-select-section">
                     <select
                    value={pageSize}
                    onChange={e => setPageSize(Number(e.target.value))}>
                    {[10, 15,20,25,50,100].map(pageSize => (
                      <option key={pageSize} value={pageSize}>
                        Show {pageSize}
                      </option>
                    ))}
                   </select>
                </div>

      </div>
          </>
          </div>
        </div>

        {showRoom && <div className="add-room-model-wrapper">
                    <div className="add-room-model report-model">
                      <div className="add-room-model-header">
                         <h4>{roomName} Details</h4>
                      </div>
                        {/* <InputWithLable placeholder='Room Name'/>
                        <InputWithLable placeholder='No of PAX'/>
                        <InputWithLable placeholder='Room ID'/>
                        <InputWithLable placeholder='Password'/>
                        <InputWithLable placeholder='panal Id / Ip Address'/> */}
                        <div className='view-details'>
                          <span>Organiser Name</span>
                          <span>{orgName}</span>
                        </div>
                        <div className='view-details'>
                          <span>Invitees</span>
                          <div className='report-invitees'>{coMember.map((d,i)=><p key={i}>{d}</p>)}</div>
                        </div>
                        <div className='view-details'>
                          <span>Booked Date</span>
                          <span>{bdate}</span>
                        </div>
                        <div className='view-details'>
                          <span>Start Time</span>
                          <span>{startTime}</span>
                        </div>
                        <div className='view-details'>
                          <span>End Time</span>
                          <span>{endTime}</span>
                        </div>
                        <div className='view-details'>
                          <span>Reserved Date</span>
                          <span>{rdate}</span>
                        </div>
                        <div className='view-details'>
                          <span>Status</span>
                          <span>{status}</span>
                        </div>
                        <div className='view-details'>
                          <span>No of PAX</span>
                          <span>{noPax}</span>
                        </div>
                        <div></div>
                        <div className="add-room-model-btn">
                            <button className='bluebtn reset-btn' onClick={cancel}>Close</button>
                            {/* <button className='bluebtn book-btn'>Create</button> */}
                        </div>
                    </div>
                    </div>}
 
    </>

  )
}

export default Report


