






import '../Styles/global.css'
import '../Styles/UserManagement.css'
import React, { useMemo,useState,useEffect } from "react";
import "react-calendar/dist/Calendar.css";
import { FiChevronLeft,FiChevronRight,FiChevronsLeft,FiChevronsRight} from 'react-icons/fi';
import { BsGenderFemale,BsPhone} from 'react-icons/bs';
import { VscSourceControl} from 'react-icons/vsc';
import { MdOutlineManageSearch} from 'react-icons/md';
import { AiFillCloseCircle} from 'react-icons/ai';
import {BiEdit} from 'react-icons/bi'
import { useTable,usePagination,useFilters, useGlobalFilter ,useSortBy } from 'react-table'
import MOCK_DATA from '../helper/User.json'
import { User } from '../helper/columns'
import { AiOutlineCalendar } from 'react-icons/ai';
import { BsCreditCard2Front } from 'react-icons/bs';
// import { GlobalFilter } from "../components/table_filter/GlobalFilter";
import { ColumnFilter } from '../components/table_filter/ColumnFilter'
import axios from "axios";
import { useNavigate } from "react-router-dom";
import formWrap from '../assests/formWrap.png'
import cardWrap from '../assests/cardWrap.png'
import InputWithLable from '../components/input/InputWithLable';
function UserManagement() {
  const [roomTableData ,setRoomTableData] = useState([])
  const [departmentData ,setdepartmentData] = useState([])
  const [showRoom, setshowRoom] = useState(false)
  const [showRoom2, setshowRoom2] = useState(false)
  const [roomName, setroomName] = useState(null)
  const [noPax, setnoPax] = useState(null)
  const [orgName, setorgName] = useState(null)
  const [bdate, setbdate] = useState(null)
  const [rdate, setrdate] = useState(null)
  const [startTime, setstartTime] = useState(null)
  const [endTime, setendTime] = useState(null)
  const [coMember, setcoMember] = useState(null)
  const [status, setstatus] = useState(null)
const [image ,setimage] = useState("https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png")
const [image2 ,setimage2] = useState("https://www.faxburner.com/blog/wp-content/uploads/2017/12/iStock-628536910-e1627389334567.jpg")

  const columns = useMemo(() => User, [])
  const data = useMemo(() =>MOCK_DATA , [])
  const history = useNavigate()
  const defaultColumn = React.useMemo(
    () => ({
      Filter: ColumnFilter
    }),
    []
  )

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    gotoPage,
    pageCount,
    setPageSize,
    prepareRow,
    // setGlobalFilter
  } = useTable(
    {
      columns,
      data,
      defaultColumn,
      initialState: { pageIndex: 0 }
    },
    useFilters,
    useGlobalFilter,
    useSortBy,
    usePagination,
  )
  const { pageIndex, pageSize } = state

  





  const EditRoom = (d)=>{
    console.log(d);
  setroomName(d.room_name)
  setnoPax(d.no_of_pax)
  setorgName(d.organiser_name)
  setbdate(d.booking_date)
  setrdate(d.reserved_date)
  setstartTime(d.start_time)
  setendTime(d.end_time)
  setstatus(d.current_status)
  setcoMember(d.co_member)
  console.log(coMember);
  setshowRoom2(true)
  setshowRoom(false)
  }
  
  const cancel = ()=>{
    setshowRoom(false)
  }
  // 

function exportPDF(id) {
window.print()
}
const AddUser = ()=>{
  setshowRoom(true)
}
const reload = ()=>{
  history(0)
}
const reset = ()=>{
  reload()
}
  // 
  return (
    <>
        <div className='app-header'> 
          <h1>UserManagement</h1>
          {/* <InputField icon={<BiSearchAlt2/>} placeholder='Search' type='text'/>   */}

        </div>
        <div className='report-btn'>
              {/* <button id='HotDesking' className='report-btn-item   active' onClick={MeetingRoom}>Meeting Room</button> */}
              {/* <button id='Room' className='report-btn-item  ' onClick={Room}>Meeting Room</button>
              <button id='Locker' className='report-btn-item  ' onClick={Locker}>Locker</button> */}
          </div>
        <div className='  border-radius5px management-wrapper box-shadow'>
          <div className='manament-table-header'>
            <span className='AllertaFont'>UserManagement</span>
            <div className='btn-divder'>

                    {/* <Multiselect
                    className='blue-btn-box usermangement-room-book-btn'
                      displayValue="departmentName"
                      onKeyPressFn={function noRefCheck(){}}
                      onRemove={function noRefCheck(){}}
                      onSearch={function noRefCheck(){}}
                      onSelect={function noRefCheck(){}}
                      options={departmentData}
                      singleSelect
                    /> */}


            <button className='blue-btn-box usermangement-room-book-btn' onClick={AddUser}>Add User</button>
            <button className='blue-btn-box usermangement-room-book-btn' onClick={()=>exportPDF('test')}>Export <AiOutlineCalendar/></button>
            <select name="cars" id="status" className='blue-btn-box usermangement-room-book-btn report-department-select'  >
                  <option value="" disabled selected>Select</option>
                  <option value="Completed">Month</option>
                  <option value="Reserved">Day</option>
                  <option value="Occupied">Week</option>
                  {/* {departmentData.map((d,i)=>{
                    return <option key={i} value={d.departmentName}>{d.departmentName}</option>
                  })} */}
                </select>
            {/* <SimpleDropDown/> */}
            <button className='usermangement-reset-btn' onClick={reset}>Reset</button>
            </div>

          </div>
          {/* divder */}
          <div className='justify-center'>
          <span className='divder'></span>
          </div>

          <div className='table-container'>
          <>
      <table {...getTableProps()} id='test'>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}
               
                >
                 <div>{column.canFilter ? column.render('Filter') : null}</div>
                                 <span className="table-asc-dec"  onClick={() => column.toggleSortBy()}>
                <span>{column.render('Header')}</span> 
                <span>  {column.isSorted
                      ? column.isSortedDesc
                        ? ' 🔽'
                        : ' 🔼'
                      : ''}</span> 

                  </span>
                </th>
              ))}
              <th><div className="margintop2rem">Virtual Card</div></th>
              <th><div className="margintop2rem">Edit Profile</div></th>
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {page.map(row => {
            prepareRow(row)
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => {
                  return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                })}
                <td ><BsCreditCard2Front {...row.getRowProps()} onClick={()=>EditRoom(row.original)} className='cursor-pointer' /></td>
                <td ><BiEdit {...row.getRowProps()} onClick={()=>AddUser(row.original)} className='cursor-pointer' /></td>
              </tr>
            )
          })}
        </tbody>
      </table>
      <div className="pagination-section">


            <div className="pagination-page-section">
            <div>
              <span>
              Page
              <strong>
                {pageIndex + 1} of {pageOptions.length}
              </strong>
            </span>
          </div>
                <span>
              | Go to page:{' '}
              <input
                type='number'
                defaultValue={pageIndex + 1}
                onChange={e => {
                  const pageNumber = e.target.value ? Number(e.target.value) - 1 : 0
                  gotoPage(pageNumber)
                }}
                style={{ width: '50px' }}
              />
            </span>{' '}
            </div>
                

        <div className="pagination-btn-section">
        <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
         <FiChevronsLeft/>
        </button>
        <button onClick={() => previousPage()} disabled={!canPreviousPage}>
        <FiChevronLeft/> <span>Previous</span>
        </button>
        <button onClick={() => nextPage()} disabled={!canNextPage}>
        <span>Next</span>   <FiChevronRight/>
        </button>
        <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
        <FiChevronsRight/> 
        </button>
        </div>

                <div className="pagination-select-section">
                     <select
                    value={pageSize}
                    onChange={e => setPageSize(Number(e.target.value))}>
                    {[10, 15,20,25,50,100].map(pageSize => (
                      <option key={pageSize} value={pageSize}>
                        Show {pageSize}
                      </option>
                    ))}
                   </select>
                </div>

      </div>
          </>
          </div>
        </div>

        {showRoom && <div className="add-room-model-wrapper">
                    <div className="add-room-model report-model">
                     <div className='formWrap'>
                      <img src={formWrap} alt='dfdfd'></img>
                     </div>
                     <h1 className='add-room-model-header'>Employee Details</h1>
                     <InputWithLable placeholder="Full Name"></InputWithLable>
                     <div className='input-withlable-container '>

                    <span>Gender</span>
                      <div className='radio-f'>
                      <div className='flex-radio'>
                  <input type="radio" id="css" name="fav_language" value="CSS"/>
                  <label for="css">Male</label>
                    </div>
                    <div className='flex-radio'>
                    <input type="radio" id="javascript" name="fav_language" value="JavaScript"/>
                  <label for="javascript">FeMale</label>
                    </div>
                      </div>


                    </div>
                     <InputWithLable placeholder="Designation"></InputWithLable>
                     <InputWithLable placeholder="Department"></InputWithLable>
                     <InputWithLable placeholder="Email"></InputWithLable>
                     <InputWithLable placeholder="Phone Number"></InputWithLable>
                     <div className='facility-section'>
                            <span className='header'>Employee Image</span>
                            <div className='flex-column-with-row'>
                          <input className='file-selection' id='userProfile' type='file'/>
                          {image && <div className="user-profile-wrapper">
                                                <img src={image} alt="user-Profile-img"></img>
                          </div>}
                            </div>
                      </div>
                      <div className='btns'>
                  <button className='create-btn cancel-btn' onClick={cancel}>Cancel</button>
                  {image ?
                  <button className='create-btn'  >Create</button>:
                  <button className='create-btn'  >Update</button>
                  
                  }
              </div>
                    </div>
                    </div>}
                  {showRoom2 && <div className='virutal-card-wrapper'>
                    <div className='virtual-model'>
                     
                    <div className='cardWrap'>
                    <span className='closeBtn' onClick={()=>setshowRoom2(false)}><AiFillCloseCircle/></span>
                      <img src={cardWrap} alt='dfdfd'></img>
                     </div>
                     <div className='virtual-data'>
                     {image2 && <div className="vitual-profile-wrapper">
                                                <img src={image2} alt="user-Profile-img"></img>
                          </div>}
                          <div>
                           <p>Joe Angel</p>
                           <p><BsGenderFemale/>Female 28</p>
                           <p><VscSourceControl/>Ceo</p>
                           <p><MdOutlineManageSearch/>Management</p>
                           <p><BsPhone/>6895215862</p>

                          </div>
                     </div>
                    </div>
                    </div>}

 
    </>

  )
}

export default UserManagement


